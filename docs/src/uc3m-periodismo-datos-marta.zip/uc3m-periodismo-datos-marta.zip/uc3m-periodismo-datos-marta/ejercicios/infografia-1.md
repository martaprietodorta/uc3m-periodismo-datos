[Inforgrafía](https://cincodias.elpais.com/cincodias/2021/05/05/companias/1620205074_988678.html)

## Práctica 1: Comentario de la Infografía

15.09.2021
La infografía a desarrollar se trata de un cuadro eplicativo acerca de como cambia e precio de la luz dependeindo de la hora a la que se quiera potenciar su consumo en el hogar. 
Esta infografía va acerca de la nueva ley de energía eléctrica publicada el 1de junio. 

# Explicación de la Infografía

En la tabla aparece un cuadro explicativo csobre los periodos horarios donde varía el precio de la luz que afecta tanto a territorio de La Península como el archipiélago Balear y canario. 
En "Hora Punta" figura en color rojo los horario donde la luz será mucho más cara como son de 10:00 a 14:00 de la tarde y de 18:00 a 22:00 de la noche. 
En "Hora llana" de color naranja figura el precio medio donde la luz es un poco más barata, de 8:00 a 10:00 de la mañana, de 14:00-18:00 de la tarde y de 22:00 a 24:00 de la noche.
En "Hora valle" figura en color verde el tramo horario donde la luz sale mucho más barata, que es de 00:00 a 8:00 de la mañana.
Cabe mencionar como los findes de semana es de 00:00 a 24:00 "Hora valle"

Vemos que en el caso de las ciudades autónomas de Ceuta y Melilla el horario es diferente por lo que nos indica la infografía. 
En "Hora Punta" de color rojo entra dentro del siguiente horario, de 11:00 a 15:00 de mañana y de 19:00 a 23:00h de la noche
En "Hora llana" de color naranja, figura el siguiente horario: 8:00 - 11:00h, de 15:00 a 19:00h y 23:00 a 24:00h
En "Hora valle" de color verde, de 00:00 a 8:00h como en el caso del resto del territorio

# Explicaciones

En el extremo izquierdo aparece una leyenda que explica el tipo de peaje a pagar, la potencia contratada y los nuevos formatos
