PASOS A SEGUIR PARA LA CREACIÓN DE PÁGINA WEB:

El primer paso será descargarse la aplicación de Pandoc para poder cambiar todos los formatos en .md a HTML. 

Lo siguiente será descargar la carpeta de “Sticky-footer-header”, la cual es fundamental para la creación de la página web. Posteriormente se creará dentro de esta carpeta, a través de la terminal, dos carpetas con los nombres “cls”, “js”y metemos dentro de estas los documentos que se encontraban en los formatos correspondientes a las carpetas. 

El tercer paso será crear una carpeta a la que llamaremos “Docs” para poder copiar las prácticas que hemos hecho durante el curso que las pasaremos en formato HTML y aparecerán en GitHub. Una vez que tenemos todas las prácticas realizadas durante el curso en formato HTML en la carpeta de Docs (que hemos convertido los documentos de formato .md a HTML gracias a la aplicación de Pandoc desde la terminal) añadimos el índex para poder hacer visible y ordenadamente nuestra web. Una vez hecho el paso anterior y teniendo todos los documentos en la carpeta de Docs, vamos eliminado los archivos en formato md. 

En la terminal para poder poner los archivos HTML vamos abriendo uno por uno en la terminal dentro del archivo de Index.html con el nano para ir modificando en lenguaje para que se vea en la página web una por una con los nombres “practica-1.html”, “practica-2.html” y “practica-4.html”. Tras revisarlo todo, lo guardé con control O y salí de nano con control X.

En el pie del archivo html en nano ponemos el resumen del contenido de la página web para que aparezca al final de todas las actividades. Al final aparece: “conjunto de trabajos de la asignatura “Periodismo de Datos” 2021/2022 de Marta Prieto lo guardamos. 

A continuación subiremos todas las prácticas, una vez que están subidas las prácticas vemos si tenemos errores para modificarlas desde la terminal. Una vez que todo está correcto, el último archivo a subir será esta memoria que se subirá de igual manera a la página web con el mismo procedimiento que las otras actividades. 

