# uc3m-periodismo-datos 
21.09.2021

##CLASE MAGISTRAL SOBRE EL PERIODISMO DE DATOS

SQL: Periodism ode base de datos (lenguaje de consultas estructuradas, íntimamente relacionadas con lenguaje de bases de datos) CSV: Valores separados por comas (en los ordenadores se usaba un programa que era el "FILTER TAU" hay veces que el programa y el lenguaje es lo mismo. markdown: Programa es una sintaxis para texto de lenguaje natural, texto corrido o lo que en términos de tipos de datos serían "SRINGS" TAB; TABULADOR TECLA A LA IZQUIERDA EN MEDIO QUE TIENE FLECHA PARA UN LADO Y OTRO (<>) es el TSV: VALORES SEPARADOS POR TABULACIÓN SV: VALORES SEPARADOS POR CUALWUEIR CARÁCTER.

Hay 3 tipos de formatos de datos: sacamos fuera las bases de datos SQL 1º asteriscos CSV 2º los JSON: va a estructurar texto 3º Datos en XML: puente entre mundo de texto y mundo de los datos

Nombres deben ir entre tabulación.

no todos los csv están listos para usarse ROWS AND COLUMNS: FILAS Y COLUMNAS (PRIMERA FILA DE TABLA SUELE SER LA QUE TIENE O INDIQCA QUE TIPO DE INFROMACIÓN HAY EN LA TABLA) Fecha en tabla; es otro tipo de dato aunque esté escrito en datos DATE: YYYY-MM-DD (Consistencia de este tipo de datos se pueden fastidiar los tipos de cálculos)

DATOS BOOLEANOS: 0 o 1, true or false, sí o no, (todo lo que sea una posibilidad u otra) No hay tildes en la aplicación de datos ordenada por orden alfabético

TABLA DE EJEMPLO DE LISTA DE NOMBRES DE CLASE FORMATO DE DATOS NUMÉRICO: COLUMNA CON DATOS Y APELLIDOS EN FORMATO NATURAL uppercase () lowercase() capital letter case hemos visto el tipo de formato que se llama "STRINGS": cadena de caracteres (tipo de dato en la tabla)

CLASE PRÁCTICA 15.09.2021

QUE ES EL PERIODISMO DE DATOS Hardware; como lo que es el aparato Software: parte ligera, que es parte lógica del ordenador FLORENCE NIGHTIGALE 1820-1910 Fue enfermera, escritora y estadística. Considerada pionera de la enfermería moderna. Creadora del primer modelo concpetual de enfermería. CHARLES MINARD 1781 -
